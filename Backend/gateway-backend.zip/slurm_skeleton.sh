#!/bin/bash
#SBATCH --job-name="JOB_NAME"
#SBATCH --output="JOB_NAME.%j.%N.out"
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#SBATCH --export=ALL
#SBATCH -t 01:30:00
#SBATCH -A TG-CCR160005
