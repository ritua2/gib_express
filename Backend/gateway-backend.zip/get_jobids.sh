showq -u | tail -n +4 | grep tantrung | sed -e "s/[ ]\+/ /g" | cut -d " " -f2
