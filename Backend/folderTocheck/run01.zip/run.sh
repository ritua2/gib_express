#!/bin/bash

./hello