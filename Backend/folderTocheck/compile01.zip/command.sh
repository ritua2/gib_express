#!/bin/bash

gcc -o a.out hello